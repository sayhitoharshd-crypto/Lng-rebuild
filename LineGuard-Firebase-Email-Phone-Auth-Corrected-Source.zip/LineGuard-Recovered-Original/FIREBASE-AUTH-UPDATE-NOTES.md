# LineGuard Firebase authentication update

- Uses the Firebase Android project configuration supplied for `lineguard-68bb0` and package `com.lineguard.app`.
- Email/password uses native Firebase Authentication.
- Phone OTP uses native Firebase Phone Authentication.
- Google and anonymous providers are not implemented.
- Android builds require the Firebase project to have Email/Password and Phone providers enabled, and Phone auth's required app verification/SHA fingerprints configured in Firebase Console.
- This source archive has not yet been built or tested on a physical Android device. The GitHub Actions workflow builds a release APK and checks for the packaged JS bundle. A successful workflow is required before installation.
